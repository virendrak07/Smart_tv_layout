import React from 'react'

const SupportSettings = () => {
    return (
        <div className="profile-content" id="picture">
            <div className="row">
                <div className="col-md-12">
                    <h3>Supprot</h3>
                </div>
                <div className="col-md-12">
                    <ul>
                        <li>Software Update</li>
                        <li>Device Care</li>
                        <li>Remote Management</li>
                        <li>About This Television</li>
                    </ul>
                </div>
            </div>
        </div>
    )
}

export default SupportSettings